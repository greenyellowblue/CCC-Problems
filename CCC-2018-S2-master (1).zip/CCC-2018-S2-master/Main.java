import java.util.Scanner;
public class Main {
	public static void main(String[]args){
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int flowers [] [] = new int [N] [N];
		String correct  = "false";
		
		for(int i = 0; i < N; i++){
			for(int x = 0; x < N; x++){
				flowers[i][x] = sc.nextInt();
			}
		}
		
		for(int i = 0; i < N-1; i++){
			for(int x = N-1; x > 0; x--){
				if(flowers[i][x] > flowers[i+1][x] && flowers[i][x] > flowers[i][x-1]){
					correct = "false";
					break;
				}
				else if(flowers[i][x] > flowers[i+1][x] && flowers[i][x] < flowers[i][x-1]){
					
					correct = "180";
					break;
				}	
				else if(flowers[i][x] < flowers[i+1][x] && flowers[i][x] > flowers[i][x-1]){
					for(int m = 0; m < N; m++){
						for(int n = 0; n < N; n++){
							System.out.print(flowers[m][n] + " ");
						}
						System.out.println("");
					}
					correct = "neither";
					
				} else{
					
					correct = "true";
					
				}
				if(correct == "false" || correct == "180")
					break;
			}
			if(correct == "false" || correct == "180")
				break;
		}
		
		if (correct == "true"){ 
			
			for(int x = N-1; x > -1; x--){
				for(int i  = 0; i < N; i ++){
					System.out.print(flowers[i][x] + " ");
				}
				System.out.println("");
			}
		
		}	else if (correct == "180"){
			
			for(int i = N-1; i > -1; i--){
				for(int x  = N-1; x > -1; x --){
					System.out.print(flowers[i][x] + " ");
				}
				System.out.println("");
			}
		}else if (correct == "false"){
			
			for(int x = 0; x < N; x++){
				for(int i  = N-1; i > -1; i --){
					System.out.print(flowers[i][x] + " ");
				}
				System.out.println("");
			}
		}
			
			
		
	}
}